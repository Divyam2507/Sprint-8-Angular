package com.cg.ibs.loanmgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ibs.loanmgmt.entities.LoanTypeEntity;

public interface LoanTypeDao extends JpaRepository<LoanTypeEntity, Integer> {
	LoanTypeEntity findByInterestRate(Float interestRate);
	
}
