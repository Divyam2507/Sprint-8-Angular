package com.cg.ibs.loanmgmt.entities;

public enum AccountStatus {
	ACTIVE, CLOSED;
}
