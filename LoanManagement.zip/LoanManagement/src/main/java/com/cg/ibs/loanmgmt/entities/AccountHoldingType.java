package com.cg.ibs.loanmgmt.entities;

public enum AccountHoldingType {
	PRIMARY, SECONDARY, INDIVIDUAL;
}
