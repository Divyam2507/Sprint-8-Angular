package com.cg.ibs.loanmgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.entities.AccountHolding;
import com.cg.ibs.loanmgmt.entities.Customer;
import java.util.List;

@Repository("accountHoldingDao")
public interface AccountHoldingDao extends JpaRepository<AccountHolding, Long> {
	List<AccountHolding> findByCustomer(Customer customer);
}
