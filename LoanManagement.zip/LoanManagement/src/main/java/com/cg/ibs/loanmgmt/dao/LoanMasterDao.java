package com.cg.ibs.loanmgmt.dao;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.Customer;
import java.util.List;
import java.util.Optional;

import com.cg.ibs.loanmgmt.entities.LoanStatus;

@Repository("loanMasterDao")
public interface LoanMasterDao extends JpaRepository<LoanMasterEntity, BigInteger> {
	@Query("select l from LoanMasterEntity l where l.status = 'APPROVED' AND l.customer=:customer")
	List<LoanMasterEntity> findForEmiByCustomer(Customer customer);

	@Query("select l from LoanMasterEntity l where l.status = 'APPROVED' AND l.customer=:customer")
	List<LoanMasterEntity> findForPreClosureByCustomer(Customer customer);

	@Query("select l from LoanMasterEntity l where l.status = 'SENT_FOR_VERIFICATION' AND l.loan_Approver=:banker")
	List<LoanMasterEntity> findLoansToBeVerified(Banker banker);
	
	@Query("select l from LoanMasterEntity l where l.status = 'PRE_CLOSURE_VERIFICATION' AND l.loan_Approver=:banker")
	List<LoanMasterEntity> findPreClosureLoansToBeVerified(Banker banker);

	@Query("select MAX(l.applicationNumber) from LoanMasterEntity l")
	BigInteger findMaxApplicationNumber();

	@Query("select l from LoanMasterEntity l where l.applicationNumber=:applicationNumber")
	LoanMasterEntity findLoansByAppNum(BigInteger applicationNumber);

	LoanMasterEntity findByLoanAccountNumber(BigInteger loanAccountNumber);

	@Query("select l from LoanMasterEntity l where l.status = 'SENT_FOR_VERIFICATION'")
	List<LoanMasterEntity> findAllVerificationLoans();
	
	@Query("select l from LoanMasterEntity l where l.status = 'PRE_CLOSURE_VERIFICATION'")
	List<LoanMasterEntity> findAllPreVerificationLoans();

	List<LoanMasterEntity> findByCustomer(Customer customer);
}
