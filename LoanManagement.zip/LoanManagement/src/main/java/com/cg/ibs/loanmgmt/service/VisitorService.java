package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;

import com.cg.ibs.loanmgmt.entities.Customer;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.CustomerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;
import com.cg.ibs.loanmgmt.model.LoanTypeModel;

public interface VisitorService {
	LoanTypeModel getTypeOfLoan(Integer typeId);

	CustomerModel verifyCustomerLogin(String userId, String password);

	BankerModel verifyBankerLogin(String userId, String password);

	BigDecimal calculatePaidInterest(LoanMasterModel loanMasterModel);

	BigDecimal calculatePaidPrinciple(LoanMasterModel loanMasterModel);
	
	CustomerModel valueOf(Customer customer);
}
