package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.ibs.loanmgmt.entities.AccountHolding;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface ApplyLoanService {
	LoanMasterModel applyLoan(LoanMasterModel loanMasterModel) throws IBSException;

	LoanMasterModel calculateEmi(LoanMasterModel loanMasterModel);

	List<AccountModel> findSavingsAccountsByCustomer(String userId) throws IBSException;

	LoanMasterModel valueOf(LoanMasterEntity loanMasterEntity);

	LoanMasterEntity valueOf(LoanMasterModel loanModel);
	
	public BigDecimal calculatePaidInterest(LoanMasterModel loanMasterModel);

	public BigDecimal calculatePaidPrinciple(LoanMasterModel loanMasterModel);
}
