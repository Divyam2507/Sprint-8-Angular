package com.cg.ibs.loanmgmt.service;

import java.util.List;

import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface VerifyLoanService {
	List<LoanMasterModel> findLoansToBeVerified(String bankerUserId);
	LoanMasterModel findLoanToBeVerified(BankerModel banker);
	LoanMasterModel verifyLoan(LoanMasterModel loanMasterModel , Integer choice);
}
