package com.cg.ibs.loanmgmt.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface VerifyPreClosureService {
	List<LoanMasterModel> findPreClosureLoansToBeVerified(String userId);
	LoanMasterModel findPreClosureLoanToBeVerified(BigInteger loanAccountNumber);
	LoanMasterModel verifyPreClosure(LoanMasterModel loanMasterModel , Integer choice) throws IBSException;
}
