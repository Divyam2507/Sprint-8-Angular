package com.cg.ibs.loanmgmt.model;

import java.math.BigDecimal;

public class LoanDetailsDisplay {

	private BigDecimal emiAmount;
	private Integer emiNumber;
	private BigDecimal principle;
	private BigDecimal interest;

	public Integer getEmiNumber() {
		return emiNumber;
	}

	public void setEmiNumber(Integer emiNumber) {
		this.emiNumber = emiNumber;
	}

	public BigDecimal getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}

	public BigDecimal getPrinciple() {
		return principle;
	}

	public void setPrinciple(BigDecimal principle) {
		this.principle = principle;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public LoanDetailsDisplay(Integer emiNumber,BigDecimal emiAmount, BigDecimal principle, BigDecimal interest) {
		super();
		this.emiNumber = emiNumber;
		this.emiAmount = emiAmount;
		this.principle = principle;
		this.interest = interest;
	}
}
