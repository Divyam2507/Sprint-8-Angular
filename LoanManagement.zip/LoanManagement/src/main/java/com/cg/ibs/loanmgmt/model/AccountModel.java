package com.cg.ibs.loanmgmt.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

import com.cg.ibs.loanmgmt.entities.AccountStatus;
import com.cg.ibs.loanmgmt.entities.AccountType;

public class AccountModel {
	private BigInteger accNo;
	private BigDecimal balance;
	private LocalDate accCreationDate;
	private AccountStatus accStatus;
	private AccountType accType;

	public BigInteger getAccNo() {
		return accNo;
	}

	public void setAccNo(BigInteger accNo) {
		this.accNo = accNo;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public LocalDate getAccCreationDate() {
		return accCreationDate;
	}

	public void setAccCreationDate(LocalDate accCreationDate) {
		this.accCreationDate = accCreationDate;
	}

	public AccountStatus getAccStatus() {
		return accStatus;
	}

	public void setAccStatus(AccountStatus accStatus) {
		this.accStatus = accStatus;
	}

	public AccountType getAccType() {
		return accType;
	}

	public void setAccType(AccountType accType) {
		this.accType = accType;
	}

}
