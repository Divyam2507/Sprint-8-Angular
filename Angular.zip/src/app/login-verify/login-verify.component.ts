import { Component, OnInit } from '@angular/core';
import { Login } from '../model/login';
import { LoginVerifyService } from '../service/login-verify.service';
import { Customer } from '../model/customer';
import { Banker } from '../model/banker';
import { ApplyLoanService } from '../service/apply-loan.service';
import { Router } from '@angular/router';
import { CustomerService } from '../service/customer.service';
import { BankerService } from '../service/banker.service';

@Component({
  selector: 'app-login-verify',
  templateUrl: './login-verify.component.html',
  styleUrls: ['./login-verify.component.css']
})
export class LoginVerifyComponent implements OnInit {
  newLogin: Login;
  result: any;
  isBanker: boolean;
  isCustomer: boolean;
  loggedInUser: any;
  customer:Customer;
  banker:Banker;


  constructor(
    private loginVerifyService: LoginVerifyService, 
    private customerService:CustomerService,
    private bankerService: BankerService,
   private router:Router ) {
    this.newLogin = new Login();
    this.isBanker = false;
    this.isCustomer = false;
  }

  ngOnInit() {
  }

  login() {
    this.loginVerifyService.login(this.newLogin).subscribe(
      (data) => {
        this.loggedInUser = data;
        sessionStorage.setItem('userId',this.loggedInUser.userId)
        if(this.newLogin.role == "CUSTOMER"){                    
          this.customerService.loggedInCustomer=this.loggedInUser;
          sessionStorage.setItem('userId',this.loggedInUser.userId)
          this.router.navigateByUrl("/custDashboard");          
        }else if(this.newLogin.role == "BANKER"){
          this.bankerService.loggedInBanker=this.loggedInUser;
          sessionStorage.setItem('userId',this.loggedInUser.userId)
          this.router.navigateByUrl("/bankDashboard");    
        }
      }
    );
  }

 

  logoutBanker(){
    
  }
}

