export class PreClosure {
    accChoice: string
    choice: string
}
