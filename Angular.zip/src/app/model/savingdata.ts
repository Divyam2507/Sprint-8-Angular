import { Customer } from './customer';
import { Banker } from './banker';

export class SavingData {
    userId: String;
customer: Customer;
 banker: Banker;
 
}


