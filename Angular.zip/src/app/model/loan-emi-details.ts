export class LoanEmiDetails {
    emiAmount:number;
    principle:number;
    interest:number;
}
