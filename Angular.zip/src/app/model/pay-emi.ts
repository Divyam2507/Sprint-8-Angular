export class PayEmi {
    choice:string;
    accChoice:string;
}
