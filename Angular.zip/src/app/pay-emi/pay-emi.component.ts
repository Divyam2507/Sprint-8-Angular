import { Component, OnInit } from '@angular/core';
import { PayEmiService } from '../service/pay-emi.service';
import { LoanMaster } from '../model/loan-master';
import { PayEmi } from '../model/pay-emi';
import { Customer } from '../model/customer';
import { LoginVerifyService } from '../service/login-verify.service';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { Account } from '../model/account';

@Component({
  selector: 'app-pay-emi',
  templateUrl: './pay-emi.component.html',
  styleUrls: ['./pay-emi.component.css']
})
export class PayEmiComponent implements OnInit {

  userId: string;
  emiDueLoans: LoanMaster[];
  selectedLoan: LoanMaster;
  emiDueLoan: LoanMaster;
  payEmi: PayEmi;
  loggedInCustomer: Customer;
  clickForDetails: boolean;
  noLoans: boolean;
  displayEmiLoans: boolean;
  emiLoanAccs: Account[];
  emiLoanAcc: Account;
  emiAccSelect: boolean;
  dispSavAcc: boolean;
  updatedLoan: LoanMaster;
  emiPaid: boolean

  constructor(
    private payEmiServ: PayEmiService,
    private customerService: CustomerService,
    private router: Router
  ) {
    this.emiDueLoans = [];
    this.selectedLoan = new LoanMaster();
    this.emiDueLoan = new LoanMaster();
    this.payEmi = new PayEmi();
    this.loggedInCustomer = new Customer();
    this.clickForDetails = false;
    this.noLoans = false;
    this.displayEmiLoans = false;
    this.emiLoanAccs = [];
    this.emiLoanAcc = new Account();
    this.emiAccSelect = false;
    this.dispSavAcc = false;
    this.updatedLoan = new LoanMaster();
    this.emiPaid = false;
  }

  ngOnInit() {
    this.loggedInCustomer = this.customerService.loggedInCustomer;
    this.getEmiDueLoans();

  }

  getEmiDueLoans() {
    this.payEmiServ.getEmiDueLoans(this.loggedInCustomer).subscribe(
      (data) => this.emiDueLoans = data
      
    );
    console.log(this.emiDueLoans)
  }

  sendMessageForNoDueEmi() {
    this.noLoans = true;
  }

  selectLoan(selectedLoan: LoanMaster) {
    this.clickForDetails = true;
    this.selectedLoan = selectedLoan;
    console.log(this.selectedLoan);
  }

  accChoice() {
    this.dispSavAcc = true;
    this.fetchAccForEmiPay();
  }

  fetchAccForEmiPay() {
    if (this.payEmi.accChoice == "1") {
      this.payEmiServ.fetchAcc(this.selectedLoan).subscribe(
        (data) => this.emiLoanAccs = data
      );
    }

    else {
      this.router.navigateByUrl('custDashboard');
    }
  }

  selectEmiLoanAcc(selectedAccount: Account) {
    this.emiAccSelect = true;
    console.log(selectedAccount.accNo);
    this.emiLoanAcc = selectedAccount;
  }

  emiPaymentChoice() {
    console.log(this.payEmi.choice);
    if (this.payEmi.choice == "1") {
      this.emiPaid = true;
      this.payEmiServ.payEmi(this.selectedLoan).subscribe(
        (data) => this.updatedLoan = data
      );
    }

    else {
      this.router.navigateByUrl('custDashboard');
    }
  }

  logoutCustomer() {
    this.customerService.logoutCustomer();
  }

  goBackFromEmi() {
    this.router.navigateByUrl('custDashboard');
  }

  gotoHome() {
    this.customerService.goToHome();
  }
  gotoViewHistory() {
    this.customerService.goToViewHistory();
  }
  gotoApplyPreClosure() {
    this.customerService.goToApplyPreClosure();
  }
}
