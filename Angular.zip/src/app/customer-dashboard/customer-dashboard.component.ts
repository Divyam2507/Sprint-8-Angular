import { Component, OnInit, Input } from '@angular/core';
import { LoanType } from '../model/loan-type';
import { ApplyLoanService } from '../service/apply-loan.service';
import { Customer } from '../model/customer';
import { LoginVerifyService } from '../service/login-verify.service';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-dashboard',
  templateUrl: './customer-dashboard.component.html',
  styleUrls: ['./customer-dashboard.component.css']
})
export class CustomerDashboardComponent implements OnInit {

  loanTypeSpec: LoanType;
  typeId: number;
  customer: Customer;
  loggedInCustomer: Customer;

  constructor(private customerService: CustomerService,
    private loginVerifyService: LoginVerifyService, private router: Router) {
    this.loanTypeSpec = new LoanType();
    this.loggedInCustomer = new Customer();
  }

  ngOnInit() {
    this.loggedInCustomer = this.customerService.loggedInCustomer;
    console.log(this.loggedInCustomer);
  }

  selectTypeId(typeId: number) {
    this.customerService.typeId = typeId;
    this.router.navigateByUrl('/applyLoan');
  }
  logoutCustomer(){
    this.customerService.logoutCustomer();
  }
}
