import { Component, OnInit } from '@angular/core';
import { LoanMaster } from '../model/loan-master';
import { ViewHistoryService } from '../service/view-history.service';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-viewhistory',
  templateUrl: './viewhistory.component.html',
  styleUrls: ['./viewhistory.component.css']
})
export class ViewhistoryComponent implements OnInit {

  loans: LoanMaster[];
  selectedLoan: LoanMaster;
  loggedInCustomer: Customer;
  loanSelect: boolean;

  constructor(private viewHistoryServ: ViewHistoryService,
    private custServ: CustomerService) {
    this.loans = [];
    this.selectedLoan = new LoanMaster();
    this.loanSelect = false;

  }

  ngOnInit() {
    this.loggedInCustomer = this.custServ.loggedInCustomer;
    this.getLoans();
  }

  getLoans() {
    this.viewHistoryServ.getLoans(this.loggedInCustomer).subscribe(
      (data) => this.loans = data
    );
    console.log(this.loans);
  }

  selectLoan(selectedLoan: LoanMaster) {
    this.loanSelect = true;
    this.selectedLoan = selectedLoan;
  }

  gotoHome() {
    this.custServ.goToHome();
  }
  gotoPayEmi() {
    this.custServ.goToPayEmi();
  }
  gotoApplyPreClosure() {
    this.custServ.goToApplyPreClosure();
  }

  logoutCustomer() {
    this.custServ.logoutCustomer();
  }
}